package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO {
	Map<Integer, Mobiles> mobileList=Util.getMobileEntries();
	@Override
	public List<Mobiles> getAllMobiles() {
		 
		 Collection<Mobiles> collection = mobileList.values();
		 List<Mobiles> mobilelist = new ArrayList<>();
		 mobilelist.addAll(collection);
		return mobilelist;
	}

	@Override
	public boolean deleteMobile(int mobileId) {
		   boolean idFlag=false;
	        if(mobileList.containsKey(mobileId)) {
	            mobileList.remove(mobileId);
	            idFlag=true;
	        }
	        else {
	            try {
	                throw new MobileException("Id does not exists");
	            } catch (MobileException e) {
	                System.out.println(e.getMessage());
	            }
	        }
	        Collection<Mobiles> collection=mobileList.values();
	        List<Mobiles> mobiles=new ArrayList<>();
	        mobiles.addAll(collection);
	        return false;
	    }
	}


