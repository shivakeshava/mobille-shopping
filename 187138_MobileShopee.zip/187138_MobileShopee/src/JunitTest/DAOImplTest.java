package JunitTest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class DAOImplTest {

	 MobileDAOImpl dao=null;
	    @Before
	    public void setUp() throws Exception {
	        dao=new MobileDAOImpl();
	    }

	 

	    @After
	    public void tearDown() throws Exception {
	        dao=null;
	    }

	 

	    @Test
	    public void testGetAllMobiles() {
	        List<Mobiles> mobileList=dao.getAllMobiles();
	        assertEquals(4, mobileList.size());
	    }

	 

	    @Test
	    public void testDeleteMobile() {
	        assertEquals(false, dao.deleteMobile(103));
	    }
	    

	    @Test
	    public void testGetAllProductsAsNegetive() {
	        List<Mobiles> mobileList=dao.getAllMobiles();
	        assertNotNull(mobileList);
	    }

	
	    @Test
	    public void testDeleteMobileAsNegetive() {
	        assertEquals(false, dao.deleteMobile(123));
	    }

	 
}
